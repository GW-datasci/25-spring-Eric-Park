import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler
from sklearn.linear_model import LinearRegression
import matplotlib.pyplot as plt

# File paths for datasets
file_paths = {
    "inflation": "data/T20YIEM.csv",
    "gdp": "data/GDP.csv",
    "payroll": "data/PAYEMS.csv",
    "credit_spreads": "data/BAMLC0A0CM.csv",
    "nasdaq": "data/NASDAQ.csv"
}

# Load CSV file
def load_data(file_path):
    df = pd.read_csv(file_path)
    df.columns = ["DATE", "VALUE"]
    df["DATE"] = pd.to_datetime(df["DATE"])
    df.set_index("DATE", inplace=True)
    return df

# Load all datasets
dataframes = {key: load_data(path) for key, path in file_paths.items()}

# Convert NASDAQ data to monthly frequency
nasdaq_df = dataframes["nasdaq"].resample('M').last()

# Handle missing values
nasdaq_df.interpolate(method="linear", inplace=True)
nasdaq_df.fillna(method="ffill", inplace=True)
nasdaq_df.fillna(method="bfill", inplace=True)

dataframes["nasdaq"] = nasdaq_df

# Convert GDP data (Quarterly → Monthly)
gdp_df = dataframes["gdp"].resample('ME').ffill()

# Interpolate missing values
gdp_df.interpolate(method="linear", inplace=True)

# Check missing values
print("Sample of transformed GDP data:")
print(gdp_df.head(20))

print("\nMissing values in GDP data after transformation:")
print(gdp_df.isnull().sum())

# Add YEAR and MONTH columns
gdp_df["YEAR"] = gdp_df.index.year
gdp_df["MONTH"] = gdp_df.index.month

# Fill missing values if any
if gdp_df.isnull().sum().sum() > 0:
    print("Missing values detected in GDP data. Performing interpolation.")
    gdp_df.interpolate(method="linear", inplace=True)

# Predict GDP for 2025
train_gdp = gdp_df.loc["2019":].dropna()

if train_gdp.empty:
    train_gdp = gdp_df.loc["2010":].dropna()

if train_gdp.empty:
    raise ValueError("Insufficient GDP data for training. Check data transformation.")

# Train linear regression model
X_train = train_gdp[["YEAR", "MONTH"]]
y_train = train_gdp["VALUE"]

gdp_model = LinearRegression()
gdp_model.fit(X_train, y_train)

# Generate future dates for 2025
future_dates = pd.date_range(start="2025-01-01", end="2025-12-01", freq='M')
future_df = pd.DataFrame({"YEAR": future_dates.year, "MONTH": future_dates.month}, index=future_dates)

# Predict GDP
future_df["VALUE"] = gdp_model.predict(future_df[["YEAR", "MONTH"]])

# Append predicted data
gdp_df = pd.concat([gdp_df, future_df])

print("GDP prediction complete. 2025 data added.")

# Interpolate missing values across all datasets
for key, df in dataframes.items():
    df.interpolate(method='linear', inplace=True)

# Apply standard scaling
scaler = StandardScaler()
for key, df in dataframes.items():
    df["VALUE_scaled"] = scaler.fit_transform(df[["VALUE"]])

# Add lagged value and rolling average (3-month)
for key, df in dataframes.items():
    df["VALUE_lag1"] = df["VALUE"].shift(1)
    df["VALUE_roll3"] = df["VALUE"].rolling(window=3).mean()

# Rename columns to avoid conflicts
dataframes["inflation"].rename(columns={
    "VALUE": "Inflation", "VALUE_scaled": "Inflation_scaled", 
    "VALUE_lag1": "Inflation_lag1", "VALUE_roll3": "Inflation_roll3"
}, inplace=True)

gdp_df.rename(columns={
    "VALUE": "GDP", "VALUE_scaled": "GDP_scaled", 
    "VALUE_lag1": "GDP_lag1", "VALUE_roll3": "GDP_roll3"
}, inplace=True)

dataframes["payroll"].rename(columns={
    "VALUE": "Payroll", "VALUE_scaled": "Payroll_scaled", 
    "VALUE_lag1": "Payroll_lag1", "VALUE_roll3": "Payroll_roll3"
}, inplace=True)

dataframes["credit_spreads"].rename(columns={
    "VALUE": "Credit_Spreads", "VALUE_scaled": "Credit_Spreads_scaled", 
    "VALUE_lag1": "Credit_Spreads_lag1", "VALUE_roll3": "Credit_Spreads_roll3"
}, inplace=True)

dataframes["nasdaq"].rename(columns={
    "VALUE": "NASDAQ", "VALUE_scaled": "NASDAQ_scaled", 
    "VALUE_lag1": "NASDAQ_lag1", "VALUE_roll3": "NASDAQ_roll3"
}, inplace=True)

# Merge all datasets with outer join
merged_df = dataframes["inflation"]\
    .merge(gdp_df, left_index=True, right_index=True, how="outer")\
    .merge(dataframes["payroll"], left_index=True, right_index=True, how="outer")\
    .merge(dataframes["credit_spreads"], left_index=True, right_index=True, how="outer")\
    .merge(dataframes["nasdaq"], left_index=True, right_index=True, how="outer")

# Fill missing values using forward fill
merged_df.ffill(inplace=True)

# Check missing values
print("Missing values after merging:")
print(merged_df.isnull().sum())

# Raise an error if the final dataset is empty
if merged_df.empty:
    raise ValueError("Merged dataset is empty. Check the merge process.")

# Save processed data
merged_df.to_csv("processed_data.csv")
print("Processing complete. Data saved as processed_data.csv.")

# Plot data distribution
plt.hist(merged_df["VALUE_scaled"], bins=50)
plt.title("Scaled Data Distribution")
plt.show()
